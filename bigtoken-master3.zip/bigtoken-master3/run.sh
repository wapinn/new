#!/bin/bash
clear
date

node index.js
sleep 100
# rerun myself
exec $0